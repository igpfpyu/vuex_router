# vuex_router
vue router and vuex 
