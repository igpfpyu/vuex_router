<template>
    <div>
        <P>Error</P>
    </div>
</template>

<script>
    export default {
        name: "Error"
    }
</script>

<style scoped>

</style>
