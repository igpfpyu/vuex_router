import mutations from './mutations'
import actions from './actions'
import getters from './getters'
const state={
    lesson:12
}
export default {
    state,
    getters,
    mutations,
    actions
}
