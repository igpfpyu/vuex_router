import {ITEM_CLICK} from "./mutationType";
export default {
    [ITEM_CLICK](state, num){
        console.log(state);
        console.log(num)
    }
}
