export default {
    isLesson:(state)=>{
        console.log(state);
        if(state.lesson===12){
            return true;
        }else{
            return false;
        }
    }
}
